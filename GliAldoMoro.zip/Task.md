# Task / Gruppo Gli Aldi Moro

+ Backend: (Totale: 10:45)
- [ ]    Progett. DB (4h) [Alberto, Inglese]
- [ ]    Progett. Funzioni (4h) [Bruna, Maniscalco]
- [ ]    Integrare DB su Spring (45 min) [Bruna]
- [ ]    Implementare Funz. (2h) [Bruna, Maniscalco]

+ Frontend: (Totale: 7:15)
- [ ]    Progettazione UI/UX (2:30 h) [Callà, Negri]
- [ ]    Gestire richiesta HTTP form (45 min) [Callà, Negri]
- [ ]   Vestizione input / ui/ux (4 h) [Callà, Negri] 

+ Documentazione: (Totale: 1:30 h) - [ ]
- [ ]    Raggruppare JavaDoc (45 min) []
- [ ]    Rifinire Documentazione (45 min) []

+ Presentazione: (Totale: 2:15 h)
- [ ]    Discussione presentazione (15 min)
- [ ]    Preparare presentazione (2h)

