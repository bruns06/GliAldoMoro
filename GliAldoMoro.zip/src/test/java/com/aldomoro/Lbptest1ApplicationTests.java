package com.aldomoro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lbptest1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
