package com.aldomoro.services;

import java.util.List;
import com.aldomoro.entities.Testo;

public interface TestoService {
	Testo addTesto(Testo t);
	List<Testo> getTesti();
	Testo getTesto(int id);
	String parolaPL(int id);
}
