package com.aldomoro.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aldomoro.entities.Testo;

public interface TestoDAO extends JpaRepository<Testo, Integer> {

}
