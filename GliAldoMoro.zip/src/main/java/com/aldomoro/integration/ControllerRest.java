package com.aldomoro.integration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aldomoro.entities.Testo;
import com.aldomoro.services.TestoService;

@RestController
@RequestMapping("api")
public class ControllerRest {

	@Autowired
	private TestoService service;
	
	@GetMapping("testi")
	List<Testo> getTesto(){
		return service.getTesti();
	}
	
	@GetMapping("parolaPL")
	String parolaPL() {
		return service.parolaPL(6);
	}
	
	@PostMapping("testi")
	Testo addTesto(@RequestBody Testo t) {
		return service.addTesto(t);
	}
}
