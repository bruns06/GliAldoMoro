package com.puggioni;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.util.*;

@SpringBootApplication
public class PrjAldoMoroApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrjAldoMoroApplication.class, args);
		
        String testo = "Questo è un esempio di testo. Incollalo qui per analizzarlo. Testo testo testo.";

        int numeroFrasi = testo.split("[!?.:]+").length;

        int numeroParole = testo.split("\\s+").length;

        int numeroCaratteri = testo.replace(" ", "").length();

        Map<String, Integer> mappaParole = new HashMap<>();
        String[] parole = testo.split("\\s+");
        for (String parola : parole) {
            if (mappaParole.containsKey(parola)) {
                int contatore = mappaParole.get(parola);
                contatore++;
                mappaParole.put(parola, contatore);
            } else {
                mappaParole.put(parola, 1);
            }
        }

        String parolaPiuUsata = "";
        int contatoreMax = 0;
        for (String key : mappaParole.keySet()) {
            int contatore = mappaParole.get(key);
            if (contatore > contatoreMax) {
                contatoreMax = contatore;
                parolaPiuUsata = key;
            }
        }

        System.out.println("Numero di frasi: " + numeroFrasi);
        System.out.println("Numero di parole: " + numeroParole);
        System.out.println("Numero di caratteri: " + numeroCaratteri);
        System.out.println("Parola più usata: " + parolaPiuUsata + " (" + contatoreMax + " volte)");
	}

}